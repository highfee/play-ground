# Porduct delivery status card for website

A Pen created on CodePen.io. Original URL: [https://codepen.io/codewitharyann/pen/poERmEM](https://codepen.io/codewitharyann/pen/poERmEM).

