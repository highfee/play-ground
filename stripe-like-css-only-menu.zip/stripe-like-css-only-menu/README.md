# Stripe Like CSS Only Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/smpnjn/pen/VwKXdmy](https://codepen.io/smpnjn/pen/VwKXdmy).

