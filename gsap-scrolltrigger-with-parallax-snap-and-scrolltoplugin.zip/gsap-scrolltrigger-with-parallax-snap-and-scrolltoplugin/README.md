# GSAP ScrollTrigger with Parallax Snap and ScrollToPlugin

A Pen created on CodePen.io. Original URL: [https://codepen.io/petebarr/pen/qBOeVoz](https://codepen.io/petebarr/pen/qBOeVoz).

Demo of the great new ScrollTrigger plugin for GSAP. Used in combination with the ScrollToPlugin and SplitText plugin. Also please check out artist Duda's work at duda.ie. He's awesome! I needed something to make this design look good, and more of a real life example. Best on desktop at the mo, but pretty much responsive.

PS the artwork names aren't the real names. Just filling in gaps ;-) 