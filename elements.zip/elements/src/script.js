const { abs, floor, random } = Math

const setCSSProperty = (key, value) => {
  document.documentElement.style.setProperty(key, value)
}

const steps = [-8, -10, -6, -12]
let stepIndex = 0
let step = steps[stepIndex]
let initialAngle = 17
let hueMax = 320
const speed = 0.5
const loop = () => {
  const nextStep = steps[stepIndex + 1]
  const isLast = typeof nextStep === "undefined"
  const target = isLast ? steps[0] : nextStep
  const diff = target - step
  step += (diff / ((1 - speed) * 44))
  if (abs(target - step) < 0.01) {
    if (isLast) {
      stepIndex = 0
      const rangeSize = floor(random() * 180)
      const newStep = rangeSize / -2 + floor(random() * rangeSize)
      steps.push(newStep)
    } else {
      stepIndex++
    }
  }
  setCSSProperty('--step', `${step}deg`)
  setCSSProperty('--initial-angle', `${initialAngle += 1}deg`)
  setCSSProperty('--hue-max', hueMax -= .1)
}

setInterval(loop, 1000/60)