# Netflix Landing Page Clone

A Pen created on CodePen.io. Original URL: [https://codepen.io/bradtraversy/pen/yWPONg](https://codepen.io/bradtraversy/pen/yWPONg).

