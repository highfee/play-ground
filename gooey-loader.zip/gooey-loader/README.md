# Gooey loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/FilipVitas/pen/LYmBVmJ](https://codepen.io/FilipVitas/pen/LYmBVmJ).

