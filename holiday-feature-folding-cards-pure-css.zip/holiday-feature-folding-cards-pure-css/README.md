# Holiday Feature Folding Cards [Pure CSS]

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maza-designDev/pen/KKdmyGb](https://codepen.io/Maza-designDev/pen/KKdmyGb).

A small "holiday deals" page focusing on folding cards' design and functionality, only using HTML and CSS.
