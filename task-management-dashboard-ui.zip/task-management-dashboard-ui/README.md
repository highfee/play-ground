# Task Management Dashboard UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/aybukeceylan/pen/gOpbRPO](https://codepen.io/aybukeceylan/pen/gOpbRPO).

Inspired by : https://dribbble.com/shots/6938734-Task-Management-Dashboard-Design