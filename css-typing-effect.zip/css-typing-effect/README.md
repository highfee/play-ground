# CSS Typing Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/denic/pen/GRoOxbM](https://codepen.io/denic/pen/GRoOxbM).

