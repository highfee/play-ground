# Yet another slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/theseventh/pen/LYVqMYb](https://codepen.io/theseventh/pen/LYVqMYb).

